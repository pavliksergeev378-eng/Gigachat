__version__ = '0.27.0+cpu'
git_version = '78839c2b06c83c6cfb5c4da692ffb331bbd4c4cc'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
